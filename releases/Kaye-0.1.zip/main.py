#!/usr/bin/env python

"""
Kaye--a remake of Neru Kye, which is a remake of Kye.
"""

import sys
import source

if __name__ == "__main__":
  game = source.kaye.Kaye()
  game.main()

