#! /usr/bin/env python

"""
Kaye Core Animation and Tile Logic Control

Yeah, I know that's a massive title for this file, but massive tasks deserve
massive titles!

This class (Animator) is responsible for handling all tile interactions in every
senario. This class performs rather complex and intense computation in order to
ensure every tile works the way it's supposed to.

Although a good number of tile behaviors are based on their traits dictionary,
certain "special" tiles are hard-coded to avoid problems with unnecessary levels
of abstraction.

The implementor of this class (currently the Logic controller) needs only to be
concerned with five simple functions:
  anim_timer(self, board)
  anim_up(self, board)
  anim_left(self, board)
  anim_down(self, board)
  anim_right(self, board)
These functions stem from the five possible animation triggers: the timer and
the four arrow keys.

Do note, this module will likely be the bottleneck of the entire program, as it
frequently performs logically intense computations. Optimization may be needed.
"""

import random

from source.animator import _animcore as core
from source import events
from source import tiles
from source.tiles import logic
from source.tiles import traits
from source import types

def _intersection(l1, l2):
  l3 = []
  for i in l1:
    if i in l2:
      l3.append(i)
  return l3

class _Rocky(object):
  dr1 = ((0, 0), (-1, 1), (0, 0), (1, -1))
  dc1 = ((-1, 1), (0, 0), (-1, 1), (0, 0))
  dr2 = ((-1, -1), (-1, 1), (1, 1), (1, -1))
  dc2 = ((-1, 1), (-1, -1), (-1, 1), (1, 1))

class _Magnet(object):
  drdc = {
    "h" : ((0, -2), (0, -1), (0, 1), (0, 2)),
    "v" : ((-2, 0), (-1, 0), (1, 0), (1, 2))
  }

class _TNT(object):
  drdc = (
    (-1, -1), (-1, 0), (-1, 1),
    (0, -1), (0, 0), (0, 1),
    (1, -1), (1, 0), (1, 1)
  )

class Animator(object):
  
  # various response codes the anim_* methods can return
  # done in such a way that certain codes take precedence over others when
  # combined with a bitwise-or (|) operation.
  RES_INVALID_RESPONSE = 0
  RES_NO_RESPONSE = 1
  RES_FOUND_DIAMOND = 3
  
  def __init__(self):
    self._frame = 0
    self._frames = 4
    self._counter = 0
    self._countmax = self._frames
  
  def _begin_anim(self):
    self._animatrix = types.Matrix()
  
  def _move_kye_to(self, board, row, col, layer, dir):
    torow, tocol = logic.vec(row, col, dir)
    tostack = board[torow][tocol]
    canmove = False
    event = None
    if traits.passable_kye(tostack):
      canmove = True
      if tiles.names["diamond"] in tostack:
        # found a diamond!
        logic.pop_tile_from(tostack, tiles.names["diamond"])
        event = Animator.RES_FOUND_DIAMOND
      elif tiles.names["food"] in tostack:
        logic.pop_tile_from(tostack, tiles.names["food"])
      elif traits.hazard(tostack):
        # kye dies here
        raise events.KyeKilledEvent()
      elif _intersection(tostack, traits.kyewarpers):
        # warp the kye
        warper = _intersection(tostack, traits.kyewarpers)[0]
        # canmove == False because we're going to move kye for him
        canmove = False
        # find other warper: is it covered?
        warprow, warpcol = torow, tocol
        for r, c, l, t in logic.iterboard(board):
          if t == warper:
            if not traits.covered(board[r][c]):
              if r != torow or c != tocol:
                warprow, warpcol = r, c
                break
        # if not, warp the little guy
        if warprow != row or warpcol != col:
          logic.pop_tile(board[row][col], layer)
          logic.push_tile(board[warprow][warpcol], tiles.names["kye"])
        else:
          # he can't warp, so may as well stand on the thing
          canmove = True
      elif tiles.names["plunger"] in tostack:
        # explode all TNT
        for r, c, l, t in logic.iterboard(board):
          if t in traits.tnts:
            self._explode(board, r, c)
          elif t == tiles.names["plunger"]:
            logic.pop_tile(board[r][c], l)
      elif tiles.names["key"] in tostack:
        # handle the key event
        for r, c, l, t in logic.iterboard(board):
          if t in traits.keyed:
            logic.pop_tile(board[r][c], l)
    elif traits.pushable_kye(tostack):
      # push an object
      if self._handle_push(board, torow, tocol, dir):
        canmove = True
    if canmove:
      logic.pop_tile(board[row][col], layer)
      logic.push_tile(tostack, tiles.names["kye"])
    if event:
      return event
  
  def _move_obj_to(self, board, row, col, layer, torow, tocol):
    tile = board[row][col][layer]
    if self._place_obj_at(board, torow, tocol, tile):
      logic.pop_tile(board[row][col], layer)
  
  def _place_obj_at(self, board, row, col, tile):
    if traits.passable_obj(board[row][col]):
      if traits.destructive(board[row][col]):
        pass # return True below will cover this
      elif _intersection(board[row][col], traits.objwarpers):
        # find the other objwarper
        totile = _intersection(board[row][col], traits.objwarpers)[0]
        warprow, warpcol = row, col
        for r, c, l, t in logic.iterboard(board):
          if t == totile:
            if r != row or c != col:
              if not traits.covered(board[r][c]):
                warprow, warpcol = r, c
                break
        if warprow != row or warpcol != col:
          logic.push_tile(board[warprow][warpcol], tile)
          self._animatrix[warprow][warpcol] = True
      else:
        logic.push_tile(board[row][col], tile)
      return True
    return False
  
  def _scan_for_magnet(self, board, row, col):
    for orient in set(["h", "v"]):
      for r, c in _Magnet.drdc[orient]:
        if tiles.names["magnet_%s" % orient] in board[row + r][col + c]:
          return (r, c)
    return False
  
  def _handle_bouncer(self, board, row, col, layer):
    if self._scan_for_magnet(board, row, col):
      return False
    tile = board[row][col][layer]
    tilename = tiles.tiles[tile]["name"]
    dir = logic.letter_to_dir(tilename[-1])
    torow, tocol = logic.vec(row, col, dir)
    if self._move_obj_to(board, row, col, layer, torow, tocol):
      self._animatrix[torow][tocol] = True
    elif traits.redirector(board[torow][tocol]):
      for t in board[torow][tocol]:
        if t in traits.redirectors:
          redirector = t
      board[row][col][layer] = logic.redirect_tile(tile, redirector)
    else:
      if tiles.names["tnt_u"] in board[torow][tocol]:
        self._explode(board, torow, tocol)
      else:
        newtile = logic.reflect_tile(board[row][col][layer])
        if traits.pushable_obj(board[torow][tocol]):
          self._handle_bump(board, torow, tocol, dir)
        elif board[torow][tocol] in traits.redirectors:
          newtile = logic.redirect(tile, board[torow][tocol])
        board[row][col][layer] = newtile
    self._animatrix[row][col] = True
  
  def _handle_rocky(self, board, row, col, layer):
    if self._scan_for_magnet(board, row, col):
      return False
    tile = board[row][col][layer]
    tilename = tiles.tiles[tile]["name"]
    dir = logic.letter_to_dir(tilename[-1])
    torow, tocol = logic.vec(row, col, dir)
    tostack = board[torow][tocol]
    if self._move_obj_to(board, row, col, layer, torow, tocol):
      self._animatrix[torow][tocol] = True
    elif traits.circular(tostack) and not traits.surrounded(board, row, col):
      for i in xrange(2):
        tests = ((row + _Rocky.dr1[dir][i], col + _Rocky.dc1[dir][i]),
                 (row + _Rocky.dr2[dir][i], col + _Rocky.dc2[dir][i]))
        if traits.passable_obj(board[tests[0][0]][tests[0][1]]):
          if self._move_obj_to(board, row, col, layer, *tests[1]):
            self._animatrix[tests[1][0]][tests[1][1]] = True
    elif traits.redirector(tostack):
      redirector = (set(board[torow][tocol]) & set(traits.redirectors)).pop()
      board[row][col][layer] = logic.redirect_tile(tile, redirector)
    self._animatrix[row][col] = True
  
  def _handle_monster(self, board, row, col, layer):
    # TODO: make the monsters semi-intelligently move towards Kye
    if self._scan_for_magnet(board, row, col):
      return
    newrow, newcol = logic.vec(row, col, types.dirs["unknown"])
    if self._animatrix[newrow][newcol]:
      return False
    if self._move_obj_to(board, row, col, layer, newrow, newcol):
      self._animatrix[newrow][newcol] = True
    self._animatrix[row][col] = True
    # TODO: proximity detection to Kye
  
  def _handle_box(self, board, row, col, layer):
    tile = board[row][col][layer]
    tilename = tiles.tiles[tile]["name"]
    newrow, newcol = logic.vec(row, col, logic.letter_to_dir(tilename[-1]))
    if tilename[:-2] == "rockybox":
      newtile = tiles.names["rocky_" + tilename[-1]]
    elif tilename == "monsterbox":
      newtile = random.choice(traits.monsters)
    if traits.passable_obj(board[newrow][newcol]):
      self._place_obj_at(board, newrow, newcol, newtile)
      self._animatrix[newrow][newcol] = True
  
  def _handle_chronomorph(self, board, row, col, layer):
    tile = board[row][col][layer]
    newtile = traits.traits[tile]["chronomorphic"][1]
    if not traits.covered(board[row][col], layer):
      board[row][col][layer] = tiles.names[newtile]
    hazard = traits.traits[tiles.names[newtile]]["hazard"][0]
    hazard |= traits.traits[tiles.names[newtile]]["destructive"]
    if hazard:
      if tiles.names["kye"] in board[row][col]:
        raise events.KyeKilledEvent()
  
  def _handle_push(self, board, row, col, dir):
    pass
  
  def _handle_bump(self, board, row, col, dir):
    pushable = lambda t: traits.traits[t]["pushable"][1]
    newrow, newcol = logic.vec(row, col, dir)
    if pushable(board[row][col][tiles.layers["above"]]):
      layer = tiles.layers["above"]
    elif pushable(board[row][col][tiles.layers["normal"]]):
      layer = tiles.layers["normal"]
    elif pushable(board[row][col][tiles.layers["below"]]):
      layer = tiles.layers["below"]
    if self._scan_for_magnet(board, row, col):
      return False
    if self._move_obj_to(board, row, col, layer, newrow, newcol):
      self._animatrix[newrow][newcol] = True
    self._animatrix[row][col] = True
  
  def _handle_magnet(self, board, row, col, orient):
    for r, c in _Magnet.drdc[orient]:
      for l in logic.iterlayer():
        if traits.traits[board[row + r][col + c][l]]["magnetic"]:
          torow = r
          if abs(r) == 2:
            torow = r / 2
          tocol = c
          if abs(c) == 2:
            tocol = c / 2
          torow, tocol = row + torow, col + tocol
          if self._move_obj_to(board, row + r, col + c, l, torow, tocol):
            self._animatrix[torow][tocol] = True
          self._animatrix[row + r][col + c] = True
  
  def _handle_explosion(self, board, row, col, layer):
    logic.pop_tile(board[row][col], layer)
    logic.push_under_tile(board[row][col], tiles.names["burnt"])
  
  def _explode(self, board, row, col):
    place = False
    for layer, tile in enumerate(board[row][col]):
      if tile == tiles.names["nothing"]:
        if layer != tiles.tiles[tiles.names["nothing"]]["layer"]:
          continue
        place = True
      elif tile == tiles.names["kye"]:
        # oh boy
        raise events.KyeKilledEvent()
      elif tile in traits.tnts:
        # found TNT at explosion site
        logic.pop_tile(board[row][col], layer)
        for r, c in _TNT.drdc:
          self._explode(board, row + r, col + c)
        place = True
      elif traits.traits[tile]["destructible"]:
        logic.pop_tile(board[row][col], layer)
        place = True
    if place:
      if not tiles.names["explosion"] in board[row][col]:
        logic.push_tile(board[row][col], tiles.names["explosion"])
      self._animatrix[row][col] = True
  
  def _anim_kye_move(self, board, dir):
    krow, kcol, klayer = logic.find_kye(board)
    # following line can either:
    # 1) raise events.KyeKilledEvent
    # 2) return RES_FOUND_DIAMOND
    retcode = self._move_kye_to(board, krow, kcol, klayer, dir)
    for row in xrange(krow-1, krow+2):
      for col in xrange(kcol-1, kcol+2):
        if traits.area_hazard(board[row][col]):
          raise events.KyeKilledEvent()
    if retcode == Animator.RES_FOUND_DIAMOND:
      return retcode
  
  def anim_timer(self, board):
    self._frame = (self._frame + 1) % self._frames
    self._begin_anim()
    for row, col, layer, tile in logic.iterboard(board):
      if self._animatrix[row][col]:
        continue
      if self._frame == 0: # every 1 second
        if traits.traits[tile]["chronomorphic"][0]:
          self._handle_chronomorph(board, row, col, layer)
        if tile in traits.monsters:
          self._handle_monster(board, row, col, layer)
        elif tile in traits.bouncers:
          self._handle_bouncer(board, row, col, layer)
      if self._frame % 2 == 0: # every 1/2 second
        if tile in traits.boxes:
          self._handle_box(board, row, col, layer)
        elif tiles.tiles[tile]["name"] == "explosion":
          self._handle_explosion(board, row, col, layer)
      if not self._animatrix[row][col]: # every 1/4 second
        if tile in traits.rockies:
          if not self._animatrix[row][col]:
            self._handle_rocky(board, row, col, layer)
        elif tile in traits.magnets:
          orient = tiles.tiles[tile]["name"][-1]
          self._handle_magnet(board, row, col, orient)
  
  def anim_up(self, board):
    return self._anim_kye_move(board, types.dirs["up"])
  
  def anim_left(self, board):
    return self._anim_kye_move(board, types.dirs["left"])
  
  def anim_down(self, board):
    return self._anim_kye_move(board, types.dirs["down"])
  
  def anim_right(self, board):
    return self._anim_kye_move(board, types.dirs["right"])
  
