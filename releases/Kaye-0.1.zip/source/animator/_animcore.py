#!/usr/bin/env python

#def _move_kye_to(self, board, row, col, layer, torow, tocol):
#def _move_obj_to(self, board, row, col, layer, torow, tocol):
#def _place_obj_at(self, board, row, col, tile):
#def _scan_for_magnet(self, board, row, col):
#def _handle_bouncer(self, board, row, col, layer):
#def _handle_rocky(self, board, row, col, layer):
#def _handle_monster(self, board, row, col, layer):
#def _handle_box(self, board, row, col, layer):
#def _handle_chronomorph(self, board, row, col, layer):
#def _handle_push(self, board, row, col, dir):
#def _handle_bump(self, board, row, col, dir):
#def _handle_magnet(self, board, row, col, orient):
#def _handle_explosion(self, board, row, col, layer):
#def _explode(self, board, row, col):
#def _anim_kye_move(self, board, dir):

