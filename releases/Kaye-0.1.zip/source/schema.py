#!/usr/bin/env python

"""
Encapsulates everything I'd ever want to encapsulate regarding a scheme.

A "scheme" is a format for storing a set of levels.
A "scheme file" is an XML file from which a scheme can be generated.

The following is a detailed visualization of how a scheme is stored. The
following information and/or types are assumed:

tile_t is a type that can store a tile number (ctypes.c_int or ctypes.c_long)
trigger_t is a type that can be used to identify a trigger
event_t is a type that can be used to identify an event

scheme = {
  "name" : str,
  "description" : str,
  "msg_win" : str,
  "msg_lose" : str,
  "levels" : [{
    "name" : str,
    "hint" : str,
    "msg_win" : str,
    "msg_lose" : str,
    "tiles" : tile_t[32][32][3],
    "triggers" : {
      trigger_t : {
        "enabled" : bool,
        "operator" : str,
        "conditions" : [
          <<one or more of the following, in any desired order>>
          ("tile-at", {
            "tile" : tile_t,
            "row" : int,
            "col" : int,
            "visible" : bool,
            "negate" : bool
          }),
          ("tile-exists", {
            "tile" : tile_t,
            "visible" : bool,
            "negate" : bool
          })
        ]
        "actions" : [
          <<one or more of the following, in any desired order>>
          ("call-event", event_t),
          ("enable-trigger", trigger_t),
          ("disable-trigger", trigger_t)
        ]
      }, ...
    }
    "events" : {
      event_t : [
        <<one or more of the following, in any desired order>>
        ("display-sign", str),
        ("set-tile-at", tile_t, int, int),
        ("clear-tiles", tile_t, bool)
      ], ...
    }
  }, ...]
}
"""

import copy
import os
import xml
import xml.dom.minidom

from source import errors
from source import tiles
from source import types

def count_diamonds(level):
  diamonds = 0
  for row in level["tiles"]:
    for stack in row:
      for tile in stack:
        if tile == tiles.names["diamond"]:
          diamonds = diamonds + 1
  return diamonds

def grab_level(scheme):
  level = dict()
  level["name"] = scheme["levels"][0]["name"]
  level["hint"] = scheme["levels"][0]["name"]
  level["msg_win"] = scheme["levels"][0]["msg_win"]
  level["msg_lose"] = scheme["levels"][0]["msg_lose"]
  level["tiles"] = types.Board()
  for row, cols in enumerate(scheme["levels"][0]["tiles"]):
    for col, stack in enumerate(cols):
      for layer, tile in enumerate(stack):
        level["tiles"][row][col][layer] = types.Tile(tile)
  level["triggers"] = copy.deepcopy(scheme["levels"][0]["triggers"])
  level["events"] = copy.deepcopy(scheme["levels"][0]["events"])
  return level

def grab_next_level(scheme):
  del scheme["levels"][0]
  if scheme["levels"]:
    return grab_level(scheme)
  else:
    return None

def load(filename):
  try:
    scheme = _parse_and_validate(filename)
  except IOError, e:
    raise errors.FileError(filename, os.strerror(e.errno))
  except xml.parsers.expat.ExpatError, e:
    raise errors.XMLError(filename, e)
  return scheme

class Tally(object):
  def __init__(self):
    self._tally = dict()
  
  def tally(self, tile, row, col):
    if not tile in self._tally:
      self._tally[tile] = dict(count = 1, positions = [(row, col)])
    else:
      self._tally[tile]["count"] += 1
      self._tally[tile]["positions"].append((row, col))
  
  def get_count(self, tile):
    if not tile in self._tally:
      return 0
    else:
      return self._tally[tile]["count"]
  
  def get_positions(self, tile):
    if not tile in self._tally:
      return [()]
    else:
      return self._tally[tile]["positions"]

def _parse_and_validate(filename):
  scheme = {}
  
  lines = open(filename, "r").read()
  
  def getText(node):
    text = ""
    for n in node.childNodes:
      if n.nodeType in set([n.TEXT_NODE, n.CDATA_SECTION_NODE]):
        text = text + n.data
    return text
  
  textElem = lambda root, tag: getText(root.getElementsByTagName(tag)[0])
  
  attr = lambda node, attr: node.attributes[attr].value
  
  tree = xml.dom.minidom.parseString(lines)
  root = tree.documentElement
  scheme["name"] = attr(root, "name")
  scheme["description"] = textElem(root, "description")
  scheme["msg_win"] = textElem(root, "complete")
  scheme["msg_lose"] = textElem(root, "lose")
  
  if len(root.getElementsByTagName("level")) == 0:
    raise errors.FileError(filename, "scheme must contain at least one level")
  
  def isborder(row, col):
    if row in (0, types.LEVEL_ROWS - 1) or col in (0, types.LEVEL_COLS - 1):
      return True
    return False
  
  scheme["levels"] = list()
  for node in root.getElementsByTagName("level"):
    level = dict()
    tally = Tally()
    level["name"] = attr(node, "name")
    level["hint"] = textElem(node, "hint")
    level["msg_win"] = textElem(node, "complete")
    level["msg_lose"] = textElem(node, "lose")
    board = types.Board()
    rawtiles = textElem(node, "tiles")
    for row, rowtiles in enumerate(rawtiles.strip().split('\n')):
      for col, t in enumerate(rowtiles.strip().split()):
        t = int(t, 16)
        if not t in tiles.tiles:
          raise errors.InvalidTileError(attr(node, "name"), t, row, col)
        if isborder(row, col):
          if t != tiles.names["wall_s"]:
            raise errors.WallError(level["name"], row, col)
        tally.tally(t, row, col)
        board[row][col][tiles.tiles[t]["layer"]] = types.Tile(t)
    level["tiles"] = board
    level["triggers"] = dict()
    level["events"] = dict()
    _validate_level(level, tally)
    scheme["levels"].append(level)
  
  tree.unlink()
  
  return scheme

def _validate_level(level, tally):
  
  if tally.get_count(tiles.names["kye"]) == 0:
    raise errors.MissingKyeError(level["name"])
  elif tally.get_count(tiles.names["kye"]) > 1:
    row, col = tally.get_positions(tiles.names["kye"])[-1]
    raise errors.MultipleKyeError(level["name"], row, col)
  
  if tally.get_count(tiles.names["diamond"]) == 0:
    raise errors.DiamondError(level["name"])
  
  pairs = list()
  pairs.extend(range(tiles.names["kyewarper_0"], tiles.names["kyewarper_15"]))
  pairs.extend(range(tiles.names["objwarper_0"], tiles.names["objwarper_15"]))
  
  for tile in pairs:
    if tally.get_count(tile) > 0:
      if tally.get_count(tile) != 2:
        row, col = tally.get_positions(tile)[-1]
        raise errors.TupleError(level["name"], tile, row, col, 2)

