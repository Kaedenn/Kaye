#!/usr/bin/env python

class KyeKilledEvent(Exception):
  def __init__(self):
    super(KyeKilledEvent, self).__init__()

