#!/usr/bin/env python

import ctypes

from source.tiles import layers

LEVEL_ROWS = 32
LEVEL_COLS = 32
LEVEL_LAYERS = len(layers)

Tile = ctypes.c_int
Board = Tile * LEVEL_LAYERS * LEVEL_COLS * LEVEL_ROWS
Matrix = Tile * LEVEL_COLS * LEVEL_ROWS

dirs = dict(unknown = -1, up = 0, left = 1, down = 2, right = 3)
numdirs = len(dirs) - 1

